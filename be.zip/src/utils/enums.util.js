/* eslint-disable import/prefer-default-export */
export const GenderEnum = ['male', 'female'];
