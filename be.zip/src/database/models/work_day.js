'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Work_Day extends Model {
    static associate(models) {
      this.belongsTo(models.Schedule, {
        foreignKey: {
          name: 'schedule_id',
          allowNull: true
        },
        onDelete: 'CASCADE',
        as: 'schedule'
      });

      this.belongsTo(models.Doctor, {
        foreignKey: {
          name: 'doctor_id',
          allowNull: true
        },
        onDelete: 'CASCADE',
        as: 'doctor'
      });

      this.hasMany(models.Appointment, {
        foreignKey: '_id',
        onDelete: 'CASCADE',
        as: 'appointments'
      });

      // this.hasMany(models.Slot, {
      //   foreignKey: '_id',
      //   onDelete: 'CASCADE',
      //   as: 'slots'
      // });
    }
  }
  Work_Day.init(
    {
      _id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: DataTypes.UUIDV4,
        allowNull: true
      },
      schedule_id: {
        type: DataTypes.UUID
      },
      doctor_id: {
        type: DataTypes.UUID
      },
      day: {
        type: DataTypes.STRING
      },
      date: {
        type: DataTypes.DATE
      },
      status: {
        type: DataTypes.ENUM('active', 'inactive'),
        defaultValue: 'inactive'
      },
      from: {
        type: DataTypes.TIME,
        defaultValue: '08:00'
      },
      to: {
        type: DataTypes.TIME,
        defaultValue: '18:00'
      }
    },
    {
      sequelize,
      modelName: 'Work_Day'
    }
  );
  return Work_Day;
};
